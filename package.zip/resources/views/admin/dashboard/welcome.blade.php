@extends("layouts.dashboard")

@section("page-content")

<h1 class="text-xl uppercase"> Bienvenu sur le dashboard, pahomproblem</h1>
@endsection
